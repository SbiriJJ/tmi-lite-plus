#include <windows.h>
#include <objidl.h>
#include <comdef.h>
#include <gdiplus.h>
