param(
  [string]$Sources = (Join-Path $PSScriptRoot 'sources'),
  [string]$Build = (Join-Path $PSScriptRoot 'build')
)
$ErrorActionPreference = 'Stop'
# Prerequisites: CMake and 64-bit MinGW-w64 g++, gmake on PATH.
# Downloads are explicit: run this script only to build the optional renderer.
$revision = '0e3707f6dafebb121d98b53c64364d16fefe481d'
$micro = Join-Path $Sources "MicroTeX-$revision"
$tiny = Join-Path $Sources 'tinyxml2'
New-Item -ItemType Directory -Force -Path $Sources, $tiny | Out-Null
if (-not (Test-Path -LiteralPath $micro)) {
  $archive = Join-Path $Sources 'MicroTeX.zip'
  Invoke-WebRequest "https://codeload.github.com/NanoMichael/MicroTeX/zip/$revision" -OutFile $archive
  Expand-Archive -LiteralPath $archive -DestinationPath $Sources
  Remove-Item -LiteralPath $archive
}
foreach ($file in @('tinyxml2.cpp', 'tinyxml2.h', 'LICENSE.txt')) {
  if (-not (Test-Path -LiteralPath (Join-Path $tiny $file))) {
    Invoke-WebRequest "https://raw.githubusercontent.com/leethomason/tinyxml2/10.0.0/$file" -OutFile (Join-Path $tiny $file)
  }
}
& cmake -S $PSScriptRoot -B $Build -G 'MinGW Makefiles' -DCMAKE_BUILD_TYPE=Release "-DROOT=$micro" "-DTINYXML=$tiny" '-DCMAKE_MAKE_PROGRAM=gmake'
if ($LASTEXITCODE -ne 0) { throw 'CMake configuration failed.' }
& cmake --build $Build -j 4
if ($LASTEXITCODE -ne 0) { throw 'MicroTeX adapter build failed.' }
Write-Output "DLL: $(Join-Path $Build 'TMILiteMath.dll')"
Write-Output "Resources: $(Join-Path $micro 'res')"
Write-Output 'Copy these manually as described in MICROTEX_SETUP.md; they are not part of TMI Lite+ distribution.'
