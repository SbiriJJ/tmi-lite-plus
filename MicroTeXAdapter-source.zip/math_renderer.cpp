#include "latex.h"
#include "platform/gdi_win/graphic_win32.h"
#include <memory>
#include <stdexcept>
#include <cwchar>

// One synchronous render per library load. No C++ objects cross the DLL boundary.
extern "C" __declspec(dllexport) int RenderFormula(
    const wchar_t* formula, const char* resources, HBITMAP* output,
    wchar_t* error, int errorLength) {
  *output = nullptr;
  ULONG_PTR token = 0;
  Gdiplus::GdiplusStartupInput startup;
  if (Gdiplus::GdiplusStartup(&token, &startup, nullptr) != Gdiplus::Ok)
    return 1;
  bool initialized = false;
  int result = 0;
  try {
    tex::LaTeX::init(resources);
    initialized = true;
    {
      std::unique_ptr<tex::TeXRender> render(
        tex::LaTeX::parse(formula, 1600, 36, 12, 0xffe0e0e0));
      const int width = render->getWidth() + 40;
      const int height = render->getHeight() + 40;
      if (width <= 0 || height <= 0 || static_cast<long long>(width) * height > 16000000)
        throw std::runtime_error("Formula exceeds the 16 megapixel rendering limit.");
      Gdiplus::Bitmap bitmap(width, height, PixelFormat32bppARGB);
      {
        Gdiplus::Graphics graphics(&bitmap);
        graphics.Clear(Gdiplus::Color(255, 38, 40, 44));
        graphics.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);
        graphics.SetTextRenderingHint(Gdiplus::TextRenderingHintAntiAliasGridFit);
        tex::Graphics2D_win32 canvas(&graphics);
        render->draw(canvas, 20, 20);
      }
      if (bitmap.GetHBITMAP(Gdiplus::Color(255, 38, 40, 44), output) != Gdiplus::Ok)
        throw std::runtime_error("Could not create the rendered formula bitmap.");
    }
  } catch (const std::exception& e) {
    MultiByteToWideChar(CP_UTF8, 0, e.what(), -1, error, errorLength);
    result = 2;
  } catch (...) {
    wcsncpy(error, L"MicroTeX could not render this formula.", errorLength - 1);
    result = 3;
  }
  if (initialized) tex::LaTeX::release();
  Gdiplus::GdiplusShutdown(token);
  return result;
}
